package com.jspiders.registration.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class HibernateUtil {
	private static final SessionFactory SESSION;
	static {
      Configuration con=new Configuration();
      con.configure();
      SESSION=con.buildSessionFactory();
	}
	public static SessionFactory getSession() {
		return SESSION;
	}
	
	
}
