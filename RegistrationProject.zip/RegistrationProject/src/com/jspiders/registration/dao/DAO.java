package com.jspiders.registration.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jspiders.registration.dto.RegisterDTO;
import com.jspiders.registration.util.HibernateUtil;

public class DAO {
	public String add(RegisterDTO rdto) {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession().openSession();
			tx = session.beginTransaction();
			Query qry = session.createQuery("select name from RegisterDTO where email=? and password=?");
			qry.setParameter(0, rdto.getEmail());
			qry.setParameter(1, rdto.getPassword());
			String res = (String) qry.uniqueResult();
			if (res==null) {
				session.save(rdto);
				tx.commit();
			} else {
				
				return res;
				
				
			}

		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}
	public String get(String email,String password) {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession().openSession();
			tx = session.beginTransaction();
			Query qry = session.createQuery("select name from RegisterDTO where email=? and password=?");
			qry.setParameter(0,email);
			qry.setParameter(1, password);
			String res = (String) qry.uniqueResult();
			if (res!=null) {
				
				return res;
				
			} else {
				return null;
			}

		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
		return null;
	}

}
