package com.jspiders.registration.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jspiders.registration.dto.RegisterDTO;
import com.jspiders.registration.service.RegisterService;
@WebServlet("/login")
public class LoginController extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      String email= req.getParameter("email");
      String pwd  = req.getParameter("pwd");
      RegisterDTO rdto=new RegisterDTO();
      RegisterService regs=new RegisterService();
      try {
		String res=regs.encode(pwd, email);
		if(res==null) {
			String msg="Invalid email/password";
			HttpSession session=req.getSession();
			session.setAttribute("msg", msg);
			resp.sendRedirect("login.jsp");
		}
		else {
			HttpSession session=req.getSession();
			session.setAttribute("logname", res);
			resp.sendRedirect("loginsuccess.jsp");
			}
	} catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
	}
	}
}
