package excelUtilities;
import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadingDataFromExcel {
public String readdata(String columName)throws Exception
{
          //Accessing the excel data path//
	File file=new File("C:\\Users\\RAVINDLX\\workspace\\CleartripSBA\\src\\Datatables\\Testdata_cleartrip.xlsx");
	FileInputStream input=new FileInputStream(file);
	Workbook wb=new XSSFWorkbook(input);
	Sheet sheet1=wb.getSheetAt(0);
	int columcount=sheet1.getRow(0).getPhysicalNumberOfCells();
	String actualvalue=null;
	for(int i=0;i<columcount;i++)
	{
		int row=0;
		String columnvalue=sheet1.getRow(row).getCell(i).getStringCellValue();
		if(columnvalue.equalsIgnoreCase(columName))
		{
			actualvalue=sheet1.getRow(row+1).getCell(i).getStringCellValue();
			break;
			
		}	
	}
	wb.close();
	return actualvalue;
	
}
}
