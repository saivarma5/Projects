package browserUtilities;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import excelUtilities.ReadingDataFromExcel;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LaunchBrowser {
	public static WebDriver driver;
    
    public void browserSelection(String browserName) throws Exception
    {
                //selecting which browser to be launched//

    	switch(browserName)
           {
           case "FireFox":
        	   
        	   driver = new FirefoxDriver();
                 
                  break;
                  
            case "Chrome":
                  System.setProperty("webdriver.chrome.driver", "C:\\Users\\RAVINDLX\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
                 
                  driver = new ChromeDriver();
                  break;
           
           default:
                  System.out.println("invalid browser");                       
                  
           }
    }
    
    @BeforeTest
              //Getting browser name from the excel//
    public void browser() throws Exception
    {
           ReadingDataFromExcel data = new ReadingDataFromExcel();
           String name  =  data.readdata("Browser");
           this.browserSelection(name);                           
    }
    
    @AfterTest

          // closing the browser//
    public void closebrowser() throws Exception
    {
           if(driver!= null)
           {
             driver.close();
           }
    }
    
    @BeforeMethod
                // Application getting launch//
    public void openurl() throws Exception
    {
           driver.manage().window().maximize();
           driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //driver.get("http://www.savaari.com");--> this coding is for direct URL launch or used below coding if u want to get the URL from the excel

           ReadingDataFromExcel data = new ReadingDataFromExcel();
           String url  =  data.readdata("URL");
          driver.get(url);  
    }
}
    

@AfterMethod--> Include this annotation in the assesment if they mention to take screenhot or else dont need to include this code
         //for taking screenshot//

File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
// Now you can do whatever you need to do with it, for example copy somewhere
FileUtils.copyFile(scrFile, new File("c:\\tmp\\screenshot.png"));-->for path given as in the assement path
    


