package tests
import org.testng.annotations.*;

import browserUtilities.LaunchBrowser;
import pageObjects.*;

public class MainMethod extends LaunchBrowser  {
    
    @Test
    public void method() throws Exception 
    {
           Search ser = new Search();
           
           ser.PerformSearch(driver);
          
          
         

	
         
    }

}



