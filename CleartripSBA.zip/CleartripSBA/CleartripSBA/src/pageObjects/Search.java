package pageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import excelUtilities.ReadingDataFromExcel;

public class Search {
    ReadingDataFromExcel data = new ReadingDataFromExcel();
    
    // Provide comments whatever the action performed as per teh appliciation//

    By hotel = By.xpath(".//*[@id='Home']/div/div/ul/li/div/div[2]/aside[1]/nav/ul[1]/li[2]/a[1]");
    By where=By.xpath(".//*[@id='Tags']");
    By place=By.xpath("(.//*[@class='list']/li[2]/a)");
    By search = By.xpath(".//*[@id='ctl00_divHeader']/div[2]/div/div/input[2]");
    By fromdate=By.xpath(".//*[@id='CheckInDate']");
    By datesel=By.xpath(".//*[@id='ui-datepicker-div']/div[1]/table/tbody/tr[4]/td[5]/a");
    
  
    public void PerformSearch(WebDriver driver) throws Exception
    {
           driver.findElement(hotel).click();
           driver.findElement(where).click();
           driver.findElement(place).sendKeys(data.readdata("Place"));
           driver.findElement(fromdate).click();
           driver.findElement(datesel).click();
  
    
    

           
        
           
           
    }
    

}



