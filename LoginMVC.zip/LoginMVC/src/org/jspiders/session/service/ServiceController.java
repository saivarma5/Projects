package org.jspiders.session.service;


import org.jspiders.session.dao.DAO;
import org.jspiders.session.dto.RegisterDTO;

public class ServiceController {
	
	public int add(RegisterDTO rdto) {
    DAO rdao=new DAO();
    int res= rdao.add(rdto);
    return res;
	}
	
	public String get(String email,String pwd) {
		 DAO rdao=new DAO();
		 String name=rdao.get(email, pwd);
		 return name;
	}
}
