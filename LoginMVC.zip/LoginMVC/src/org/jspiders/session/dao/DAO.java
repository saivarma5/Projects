package org.jspiders.session.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.jspiders.session.dto.RegisterDTO;
import org.jspiders.session.util.SingleTon;

public class DAO {
	public int add(RegisterDTO rdto) {
		String firstname = rdto.getFirstname();
		String lastname = rdto.getLastname();
		String email = rdto.getEmail();
		String gender = rdto.getGender();
		String password = rdto.getPassword();
		Connection con = SingleTon.getSingle().getCon();
		try {
			PreparedStatement pstmt = con.prepareStatement("Insert into mvc.register values(?,?,?,?,?,?)");
			ResultSet rs = pstmt.executeQuery(
					"select * from register where email=\"" + email + "\" and password=\"" + password + "\"");
			if (rs.next()) {
				return -1;

			} else {
				rs = pstmt.executeQuery("select max(id) from mvc.register");

				if (rs.next()) {
					int i = rs.getInt(1) + 1;
					pstmt.setInt(1, i);
					pstmt.setString(2, firstname);
					pstmt.setString(3, lastname);
					pstmt.setString(4, email);
					pstmt.setString(5, gender);
					pstmt.setString(6, password);
					int res = pstmt.executeUpdate();
					return res;
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return 0;
	}
	
	
	public String get(String email,String pwd) {
		Connection con=SingleTon.getSingle().getCon();
		try {
			PreparedStatement pstmt=con.prepareStatement("select firstname from mvc.register where email=? and password=?");
		   pstmt.setString(1, email);
		   pstmt.setString(2, pwd);
		   ResultSet rs=pstmt.executeQuery();
		   if(rs.next()) {
			   String name=rs.getString(1);
			   return name;
		   }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
		
		
	}
}
