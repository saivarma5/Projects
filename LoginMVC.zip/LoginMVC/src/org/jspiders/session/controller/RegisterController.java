package org.jspiders.session.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jspiders.session.dto.RegisterDTO;
import org.jspiders.session.service.ServiceController;
@WebServlet("/rc")
public class RegisterController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String firstname = req.getParameter("firstname");
		String lastname = req.getParameter("lastname");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		String password = req.getParameter("pwd");
		RegisterDTO rdto=new RegisterDTO();
		rdto.setFirstname(firstname);
		rdto.setLastname(lastname);
		rdto.setEmail(email);
		rdto.setGender(gender);
		rdto.setPassword(password);
		ServiceController sc=new ServiceController();
		int res=sc.add(rdto);
		if(res==-1) {
			resp.sendRedirect("error.html");
		}
		if(res==1) {
			HttpSession session=req.getSession();
			session.setAttribute("firstname", firstname);
			RequestDispatcher rd=req.getRequestDispatcher("regsuccess.jsp");
			rd.forward(req, resp);
		}
	}
	
	
}
