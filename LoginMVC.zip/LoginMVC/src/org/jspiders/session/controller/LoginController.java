package org.jspiders.session.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jspiders.session.service.ServiceController;
@WebServlet("/login")
public class LoginController extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      String email=req.getParameter("email");
      String pwd=req.getParameter("pwd");
      ServiceController sc=new ServiceController();
      String name=sc.get(email,pwd);
      if(name==null) {
    	  resp.sendRedirect("loginfail.html");
    	 
      }
      else {
    	  HttpSession session=req.getSession();
    	  session.setAttribute("name", name);
    	  RequestDispatcher rd=req.getRequestDispatcher("loginsuccess.jsp");
    	  rd.forward(req, resp);
      }
	}
	
}
