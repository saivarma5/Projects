package org.jspiders.session.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SingleTon {
	private static final SingleTon single;
	private Connection con;
	
	private SingleTon() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mvc", "root", "root");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}
	
	static {
      single=new SingleTon();
	}
	

	public static SingleTon getSingle() {
		return single;
	}
	public Connection getCon() {
		return con;
	}
	protected void finalize() throws Throwable {
		if (con != null) {
			con.close();
		}
	}
}
