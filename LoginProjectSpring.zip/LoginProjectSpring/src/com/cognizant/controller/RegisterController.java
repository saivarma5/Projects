package com.cognizant.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.dao.UserDAO;
import com.cognizant.dto.UserDTO;

@Controller

public class RegisterController {

	@RequestMapping(value="/")
	public String register() {
    return "register";		
	}
	
	@RequestMapping(value="/regc")
	public String registerEntry(UserDTO user,Model model) {
		UserDAO dao=new UserDAO();
		boolean res=dao.add(user);
		if(res) {
			model.addAttribute("name",user.getName());
			return "regsuccess";
		}
		else {
			model.addAttribute("error","Registration unsuccesful please enter the correct data");
			return "register";
		}
	}
	
	
}
