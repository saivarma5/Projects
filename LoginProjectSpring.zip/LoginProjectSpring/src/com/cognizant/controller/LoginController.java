package com.cognizant.controller;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.dto.UserDTO;

@Controller
public class LoginController  {
	
	@RequestMapping(value="/l" )
     public String start() {
    	 return "Login";
     }
/*	
	@RequestMapping(value="/home" )
    public String home() {
   	 return "loginsuccess";
    }
	
	
	@RequestMapping(value="/loginfail" )
    public String loginfail(Model model) {
		model.addAttribute("errorMessage","Invalid username / password" );
   	 return "Login";
    }*/
	@RequestMapping(value="/login", method=RequestMethod.POST) 
	public String validate(UserDTO user, Model model) {
		Map<String,String> al=new HashMap<String,String>();
		al.put("shanmukhasai007@gmail.com","saivarma");
		al.put("ravitejavarma@gmail.com","raviteja");
		Set<Map.Entry<String,String>> set=al.entrySet();

		String email = user.getEmail();
		String password = user.getPassword();
		for(Map.Entry<String, String> a:set){
			if(a.getKey().equals(email)&&a.getValue().equals(password)){
				model.addAttribute("email",a.getKey());
				//return "loginsuccess";
				return "s";
				
			}
		}
		return null;
	}
@RequestMapping(value="/lout"/*, method=RequestMethod.GET*/)
	public String logout(HttpSession session,Model model) {
		session.invalidate();
		model.addAttribute("logout","You have succesfully logged out");
		model.addAttribute("errorMessage", "");
	
		return "Login";
	}
	
}
