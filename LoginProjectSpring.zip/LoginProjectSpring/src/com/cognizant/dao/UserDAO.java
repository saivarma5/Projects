package com.cognizant.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cognizant.dto.UserDTO;

public class UserDAO {

	public boolean add(UserDTO user) {
		Configuration cfg=null;
		SessionFactory sf=null;
		Session session=null;
		Transaction txn=null;
		/*try {*/
			 cfg = new Configuration();
			cfg.configure();
			
			sf = cfg.buildSessionFactory();
			
			session = sf.openSession();
			
		  txn = session.beginTransaction();
		 System.out.println(user.getEmail()+" "+user.getName());
			Query query = session.createQuery("select name from UserDTO where email=? and password=?");
			query.setParameter(0, user.getEmail());
			query.setParameter(1, user.getPassword());
			String res = (String) query.uniqueResult();
			if (res==null) {

				session.save(user);
				txn.commit();
				session.close();
				return true;
			} else {
				txn.rollback();
				session.close();
				return false;
			} 
		/*} catch (Exception e) {
			txn.rollback();
		}
		finally {
			session.close();
		}*/
		
	}
	
}
