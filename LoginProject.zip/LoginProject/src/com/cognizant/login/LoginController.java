package com.cognizant.login;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController  {
	
	@RequestMapping(value="/" )
     public String start() {
    	 return "Login";
     }
	
	
	@RequestMapping(value="/login", method=RequestMethod.POST) 
	public String validate(User user,BindingResult result, Model model) {
		Map<String,String> al=new HashMap<String,String>();
		al.put("shanmukhasai007@gmail.com","saivarma");
		al.put("ravitejavarma@gmail.com","raviteja");
		Set<Map.Entry<String,String>> set=al.entrySet();
		System.out.println("hi");
		String email = user.getEmail();
		String password = user.getPassword();
		int count=0;
		for(Map.Entry<String, String> a:set){
			if(a.getKey().equals(email)&&a.getValue().equals(password)){
				model.addAttribute("email",a.getKey());
				return "loginsuccess";
				
			}
			
		}
		if(count==0) {
			model.addAttribute("errorMessage","Invalid email/Password please try again");
			return "Login";
		}
		return null;
	}
@RequestMapping(value="/lout"/*, method=RequestMethod.GET*/)
	public String logout(HttpSession session,Model model) {
		session.invalidate();
		model.addAttribute("logout","You have succesfully logged out");
		model.addAttribute("errorMessage", "");
	
		return "Login";
	}
	
}
