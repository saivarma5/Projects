package com.jspiders.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.Generated;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/register")
public class RegisterController extends HttpServlet {

	Connection con = null;
	PreparedStatement pstmt = null;

	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "root");
			pstmt = con.prepareStatement("insert into servlets.registers values(?,?,?,?,?,?)");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String firstname = req.getParameter("firstname");
		String lastname = req.getParameter("lastname");
		String email = req.getParameter("email");
		String gender = req.getParameter("gender");
		String password = req.getParameter("pwd");
		ResultSet rs;
		try {
			String qry = "select count(*) from servlets.registers where email=\"" + email + "\"";
			rs = pstmt.executeQuery(qry);

			if (rs.next()) {
				int n = rs.getInt(1);

				if (n == 0) {
					rs = pstmt.executeQuery("select max(id) from servlets.registers");

					if (rs.next()) {
						int i = rs.getInt(1) + 1;

						pstmt.setInt(1, i);
						pstmt.setString(2, firstname);
						pstmt.setString(3, lastname);
						pstmt.setString(4, email);
						pstmt.setString(5, gender);
						pstmt.setString(6, password);
						int a = pstmt.executeUpdate();
						if (a == 1) {
							HttpSession session = req.getSession();
							session.setAttribute("name", firstname);
							RequestDispatcher rd = req.getRequestDispatcher("regsuccess.jsp");
							rd.forward(req, resp);
						}
					}
				} else {
					resp.sendRedirect("error.html");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void destroy() {
		super.destroy();
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
