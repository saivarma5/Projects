package com.jspiders.bank;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/tcc")
public class TransactionController extends HttpServlet {

	  Connection con;
	     PreparedStatement pstmt;
		public void init(ServletConfig config) throws ServletException {
			super.init(config);
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
				
				
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			
			
			
		}
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			 
	      Long senderAccNo=Long.parseLong(req.getParameter("Senaccno"));
			Long RecAccNo=Long.parseLong(req.getParameter("Recaccno"));
			  Long amount=Long.parseLong(req.getParameter("amount"));
			  String senQry="update servlets.bank set amount=amount-? where AccNo=?";
				String recQry="update servlets.bank set amount=amount+? where AccNo=?";
				
				try {
					pstmt=con.prepareStatement(senQry);
					pstmt.setLong(1, amount);
					pstmt.setLong(2, senderAccNo);
			     int a=   pstmt.executeUpdate();
				pstmt=con.prepareStatement(recQry);
				pstmt.setLong(1, amount);
				pstmt.setLong(2, RecAccNo);
				int b=pstmt.executeUpdate();
				if(a+b==2) {
					req.setAttribute("senAccNo", senderAccNo);
					req.setAttribute("recAccNo", RecAccNo);
					req.setAttribute("amount", amount);
					RequestDispatcher rd=req.getRequestDispatcher("succesful.jsp");
					rd.forward(req, resp);
				}
				else {
					resp.sendRedirect("transfer.html");
				}
				}
				 catch (SQLException e1) {
					e1.printStackTrace();
				}
			
			}
			
			public void destroy() {
				super.destroy();
				
				if(con!=null) {
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
			
	
	
}
