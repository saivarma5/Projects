package com.jspiders.bank;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/tc")
public class TransferController extends HttpServlet{
     Connection con;
     PreparedStatement pstmt;
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306","root","root");
			pstmt=con.prepareStatement("select * from servlets.bank where AccNo=? and pwd=?");
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	long AccNo=Long.parseLong(req.getParameter("accno"));
	String pwd=req.getParameter("pwd");
	try {
		pstmt.setLong(1, AccNo);
		pstmt.setString(2, pwd);
	ResultSet rs=pstmt.executeQuery();
	if(rs.next()) {
		req.setAttribute("senderAccNo", AccNo);
		resp.sendRedirect("transfer.html");
	}
	else {
		resp.sendRedirect("error.html");
	}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	
	}
	
	public void destroy() {
		super.destroy();
		
		if(con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}
