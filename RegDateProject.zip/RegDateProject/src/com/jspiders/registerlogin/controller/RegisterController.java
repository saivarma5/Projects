package com.jspiders.registerlogin.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jspiders.registerlogin.dto.RegDTO;
import com.jspiders.registerlogin.service.Service;
import com.jspiders.registerlogin.util.Systime;
@WebServlet("/regc")
public class RegisterController extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		String gender=req.getParameter("gender");
		String date=Systime.getDate();
		System.out.println(date);
		RegDTO rdto=new  RegDTO();
		rdto.setName(name);
		rdto.setEmail(email);
		rdto.setGender(gender);
		rdto.setPassword(password);
		rdto.setDate(date);
		Service ser=new Service();
		String res=ser.registerEncrypt(rdto);
		if(res==null) {
			HttpSession session=req.getSession();
			session.setAttribute("name", name);
			RequestDispatcher rd=req.getRequestDispatcher("regsuccess.jsp");
			rd.forward(req, resp);
		}
		else {
			resp.sendRedirect("error.html");
		}
		
	}
}
