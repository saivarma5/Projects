package com.jspiders.registerlogin.service;

import com.jspiders.registerlogin.dao.DAO;
import com.jspiders.registerlogin.dto.RegDTO;
import com.jspiders.registerlogin.util.Encrypt;

public class Service {
	public String registerEncrypt(RegDTO rdto) {
		String encryptedpassword = Encrypt.encrypt(rdto.getDate(), rdto.getPassword());
		rdto.setPassword(encryptedpassword);
		DAO dao = new DAO();
		String res = dao.add(rdto);
		return res;
	}
	public String loginEncrypt(String email,String password) {
		DAO dao=new DAO();
		String date=dao.get(email);
		if(date!=null) {
		String encryptedpassword = Encrypt.encrypt(date, password);
		String res=dao.login(email, encryptedpassword);
		
		return res;
		}
		return null;
	}

}
