package com.jspiders.registerlogin.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.jspiders.registerlogin.dto.RegDTO;
import com.jspiders.registerlogin.util.HibernateUtil;

public class DAO {
	public String add(RegDTO rdto) {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession().openSession();
			tx = session.beginTransaction();
			Query qry = session.createQuery("select name from RegDTO  where email=? ");
			qry.setParameter(0, rdto.getEmail());
			String name = (String) qry.uniqueResult();
			if (name == null) {
				session.save(rdto);
				tx.commit();
				return name;
			} else {
				return name;
			}

		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		}
		return null;
	}

	public String get(String email) {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession().openSession();
			tx = session.beginTransaction();
			Query qry= session.createQuery("select date from RegDTO  where email=? ");
			qry.setParameter(0, email);
			String date = (String) qry.uniqueResult();
			System.out.println(date);
			if (date == null) {
				return date;
			} else {
				return date;
			}

		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		}
		return null;
	}
	
	public String login(String email,String encryptedpassword) {
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession().openSession();
			tx = session.beginTransaction();
			Query qry = session.createQuery("select name from RegDTO  where email=?  and password=? ");
			qry.setParameter(0, email);
			qry.setParameter(1, encryptedpassword);
			String name = (String) qry.uniqueResult();
			if (name == null) {
				return name;
			} else {
				return name;
			}

		} catch (HibernateException e) {
			tx.rollback();
			e.printStackTrace();
		}
		return null;
	}
}
